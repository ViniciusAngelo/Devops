package br.com.valueprojects.mock_spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mock_SpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(Mock_SpringApplication.class, args);
	}

}
