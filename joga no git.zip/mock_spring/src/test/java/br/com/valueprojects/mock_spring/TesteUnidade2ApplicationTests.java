package br.com.valueprojects.mock_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesteUnidade2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
