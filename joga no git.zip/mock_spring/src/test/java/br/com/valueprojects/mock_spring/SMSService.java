package br.com.valueprojects.mock_spring;

public class SMSService {
    public void enviar(String destinatario) {
        // Método stub para simular envio de SMS
    }
}